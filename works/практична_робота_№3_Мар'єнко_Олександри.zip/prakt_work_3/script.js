function tigr_800() {
    let tigr_8 = document.querySelector('.tigr');
    tigr_8.setAttribute('src', 'images/img_800/tigr.jpg');
}
function tigr_1200() {
    let tigr_12 = document.querySelector('.tigr');
    tigr_12.setAttribute('src', 'images/img_1200/tigr.jpg');
}
function tigr_def() {
    let tigr_12 = document.querySelector('.tigr');
    tigr_12.setAttribute('src', 'images/img_def/tigr.jpg');
}


function slon_800() {
    let slon_8 = document.querySelector('.slon');
    slon_8.setAttribute('src', 'images/img_800/slon.jpg');
}
function slon_1200() {
    let slon_12 = document.querySelector('.slon');
    slon_12.setAttribute('src', 'images/img_1200/slon.jpg');
}
function slon_def() {
    let slon_12 = document.querySelector('.slon');
    slon_12.setAttribute('src', 'images/img_def/slon.jpg');
}


function caplya_800() {
    let caplya_8 = document.querySelector('.caplya');
    caplya_8.setAttribute('src', 'images/img_800/caplya.jpg');
}
function caplya_1200() {
    let caplya_12 = document.querySelector('.caplya');
    caplya_12.setAttribute('src', 'images/img_1200/caplya.jpg');
}
function caplya_def() {
    let caplya_12 = document.querySelector('.caplya');
    caplya_12.setAttribute('src', 'images/img_def/caplya.jpg');
}


